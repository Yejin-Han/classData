$(function(){
  $('.gnb').on('mouseenter',function(){
    if($(window).width()>1024){
      $('.sub').stop().slideDown(300);
      $('.gnb_bg').stop().slideDown(300);
    }
  });
  $('.gnb').on('mouseleave',function(){
    if($(window).width()>1024){
      $('.sub').stop().slideUp(250);
      $('.gnb_bg').stop().slideUp(250);
    }
  });
  $(window).resize(function(){
    if($(window).width()>1024){
      $('.gnb').show();
      $('.sub,.gnb_bg').hide();
    } else if($(window).width()>640){
      $('.gnb,.gnb_bg').hide();
      $('.sub').show();
    } else{
      $('.gnb,.sub,.gnb_bg').hide();
    }
  });
  $('#togglebtn').on('click',function(){
    $('.gnb').slideToggle(300);
  });

});